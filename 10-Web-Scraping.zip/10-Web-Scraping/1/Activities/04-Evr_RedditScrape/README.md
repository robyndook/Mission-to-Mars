# Reddit Scraper

## Instructions

* In this activity, you will scrape the Programmer-Humor.html file provided

* Use Beautiful Soup to scrape only threads that have twenty or more comments, then print the thread's title, number of comments, and the URL to the thread.

## Bonus

* If you finish early, try to display each thread's top comment in your output!

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.