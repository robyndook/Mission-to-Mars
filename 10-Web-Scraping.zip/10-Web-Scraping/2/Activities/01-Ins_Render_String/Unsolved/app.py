from flask import Flask, render_template
app = Flask(__name__)


@app.route("/")
def home():
    name = "Khaled Karman"
    text = "UC Berkeley Data Bootcamp"
    names = ["Amanda", "Henry", "Jin", "Ashwen"]
    infos = [
        {
        "name": "Amanda",
        "desc":"UC Berkeley TA",
        },
        {
        "name": "Henry",
        "desc":"UC Berkeley TA",
        },
        {
        "name": "Jin",
        "desc":"UC Berkeley TA",
        },
        {
        "name": "Ashwen",
        "desc":"UC Berkeley TA",
        },
    ]
    dog_list = [
        {"name": "Fido", "type": "Lab"},
        {"name": "Rex", "type": "Spitz"},
        {"name": "Suzzy", "type": "Shepherd"},
        {"name": "Tomato", "type": "Maltipoo"},
    ]

    return render_template("index.html", info=name, text=text, more_info=infos, names_list=names,dogs=dog_list)


if __name__=="__main__":
    app.run(debug=True)